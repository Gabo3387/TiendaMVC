﻿using Microsoft.AspNetCore.Mvc;
using StoreMVC;
using StoreMVC.Models.DTOs;
using System.Diagnostics;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHomeRepository _homeRepository;

        public HomeController(ILogger<HomeController> logger, IHomeRepository homeRepository)   
        {
            _homeRepository = homeRepository;
            _logger = logger;
        }

        public async Task <IActionResult> Index(string sterm="",int categoriaId=0)
        {
          
           IEnumerable<Producto> productos = await _homeRepository.GetProductos(sterm, categoriaId);
            IEnumerable<Categoria> categorias = await _homeRepository.Categorias();
            ProductoDisplayModel productoModel = new ProductoDisplayModel
            {
                Productos=productos,
                Categorias=categorias,
                STerm = sterm,
                CategoriaId = categoriaId
            };
            return View(productoModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}