﻿namespace StoreMVC.Constants
{
    public enum Roles
    {
    User=1,
    Admin
}
}
