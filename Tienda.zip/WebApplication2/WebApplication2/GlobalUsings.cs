﻿global using WebApplication2.Data;
global using WebApplication2.Models;
global using StoreMVC.Repositories;
global using StoreMVC.Models;
global using StoreMVC.Models.DTOs;
global using StoreMVC.Data;

