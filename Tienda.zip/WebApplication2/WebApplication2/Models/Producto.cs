﻿using Humanizer.Localisation;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace StoreMVC.Models
{
    [Table("Producto")]
    public class Producto
    {

    public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string? NombreProducto { get; set; }


        [Required]
        [MaxLength(40)]
        public string? Marca { get; set; }
        [Required]
        public double Precio { get; set; }
        public string? Imagen { get; set; }
        [Required]


        public int CategoriaId { get; set; }
        public Categoria Categoria { get; set; }
        public List<DetalleOrden> DetalleOrden { get; set; }
        public List<DetalleCarrito> DetalleCarrito { get; set; }

        [NotMapped]
        public string NombreCategoria { get; set; }
    }
}
