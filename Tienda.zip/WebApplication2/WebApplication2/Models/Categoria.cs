﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StoreMVC.Models
{
    [Table("Categoria")]
    public class Categoria
    {
        
        public int Id { get; set; }

        [Required]
        [MaxLength(40)]
        public string? NombreCategoria { get; set; }
        public List<Producto>Productos { get; set; }


    }
}

