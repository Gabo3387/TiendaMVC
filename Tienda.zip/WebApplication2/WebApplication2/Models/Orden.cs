﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations.Schema;

namespace StoreMVC.Models
{
    [Table("Orden")]
    public class Orden
    {
        public int Id { get; set; }
        [Required]
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.UtcNow;
        [Required]
        public int EstadoOrdenId { get; set; }
        public bool IsDeleted { get; set; } = false;

        public EstadoOrden EstadoOrden { get; set; }
        public List<DetalleOrden> DetalleOrden { get; set; }
       
    }
}
