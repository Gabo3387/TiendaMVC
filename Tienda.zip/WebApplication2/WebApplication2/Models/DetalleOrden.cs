﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations.Schema;

namespace StoreMVC.Models
{
    [Table("DetalleOrden")]
    public class DetalleOrden
    {
        public int Id { get; set; }
        [Required]
        public int OrdenId { get; set; }
        [Required]
        public int ProductoId { get; set; }
        [Required]
        public int Cantidad { get; set; }
        [Required]
        public double PrecioUnitario { get; set; }
        public Orden Orden { get; set; }
        public Producto Producto { get; set; }
    }
}
