﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations.Schema;

namespace StoreMVC.Models
{
    [Table("DetalleCarrito")]
    public class DetalleCarrito
    {
        public int Id { get; set; }
        [Required]
        public int CarritoId { get; set; }
        [Required]
        public int ProductoId { get; set; }
        [Required]
        public int Cantidad { get; set; }   

        public Producto Producto { get; set; }

        public Carrito Carrito { get; set; }    
    }
}
