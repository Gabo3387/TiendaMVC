﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StoreMVC.Models
{
    [Table("EstadoOrden")]
    public class EstadoOrden
    {
        public int Id { get; set; }
        [Required] 
      

        public int EstadoId { get; set; }
        [Required, MaxLength(20)]
        public string ?NombreEstado { get; set; }

    }
}
