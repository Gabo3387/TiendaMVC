﻿using Humanizer.Localisation;

namespace StoreMVC.Models.DTOs
{
    public class ProductoDisplayModel
    {
        public IEnumerable<Producto> Productos { get; set; }
        public IEnumerable<Categoria> Categorias { get; set; }

        public string STerm { get; set; } = "";
        public int CategoriaId { get; set; } = 0;
    }
}
