﻿namespace StoreMVC
{
    public interface IHomeRepository
    {
    
        Task<IEnumerable<Producto>> GetProductos(string sTerm = "", int categoryId = 0);
        Task<IEnumerable<Categoria>> Categorias();
    }
}