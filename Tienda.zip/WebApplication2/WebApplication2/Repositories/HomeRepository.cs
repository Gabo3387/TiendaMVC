﻿

using Microsoft.EntityFrameworkCore;

namespace StoreMVC.Repositories
{
    public class HomeRepository : IHomeRepository
    {
        private readonly ApplicationDbContext _db;

        public HomeRepository(ApplicationDbContext db) 
        {
            _db = db;
        } 

        public async Task<IEnumerable<Categoria>> Categorias()
            {
            return await _db.Categorias.ToListAsync();

        }
        public async Task<IEnumerable<Producto>> GetProductos(string sTerm="",int categoryId=0) 
        {
            sTerm = sTerm.ToLower();
            IEnumerable<Producto> productos = await (from producto in _db.Productos
                             join categoria in _db.Categorias
                             on producto.CategoriaId equals categoria.Id
                             where string.IsNullOrWhiteSpace(sTerm) || (producto != null && producto.NombreProducto.ToLower().StartsWith(sTerm))
                             select new Producto
                             {
                                 Id = producto.Id,
                                 Imagen = producto.Imagen,
                                 Marca = producto.Marca,
                                 NombreProducto = producto.NombreProducto,
                                 CategoriaId = producto.CategoriaId,
                                 Precio = producto.Precio,
                                 NombreCategoria = categoria.NombreCategoria
                             }
                             ).ToListAsync();

            if (categoryId > 0) 
            { 
            productos = productos.Where(a => a.CategoriaId == categoryId).ToList(); 
            }
            return productos;

        }
    }

}
